# Gidan Malam Yero — The Yeros: Footprints in the Sand of Time

A cinematic family-history website built with Next.js (App Router), TypeScript,
Tailwind CSS, Framer Motion, and Firebase — content sourced from the book manuscript.

## What's in this build

- **Full site**: Home, About the Book, all 12 chapters (Prologue → Chapter 10 →
  Epilogue) rendered from `lib/chapters.ts`, Family Tree, Timeline, Gallery, Maps,
  Legacy, Meet the Author, Contact.
- **Real book content**: every chapter's text, a pull-quote, historical notes, and
  location are pulled straight from the manuscript you provided.
- **Design system**: sand/gold/brown/emerald palette, Fraunces (display) + Inter
  (body) + IBM Plex Mono (labels/dates), the "footprint trail" motif as the site's
  sequence marker (journey stops, timeline). See `tailwind.config.ts`.
- **Motion**: Framer Motion page/scroll reveals, Lenis smooth scroll
  (`components/SmoothScroll.tsx`), animated savannah-gradient canvases.
- **Dark mode, responsive layout, reduced-motion support** (see `app/globals.css`).
- **SEO**: per-page metadata, Open Graph tags, JSON-LD, `sitemap.ts`, `robots.ts`.
- **Firebase scaffold**: `lib/firebase.ts` (client SDK) and `lib/firebase-admin.ts`
  (server SDK), with the Firestore collection shapes documented inline, plus a
  working email/password-gated `/admin` shell.

## About the chapter artwork

No AI image-generation tool was available in this build, so no chapter illustration
was rendered as a pixel file. Each of the 12 chapters instead has:

1. A full, detailed image prompt (from your brief, in `lib/chapters.ts` under
   `imagePrompt`) — historically grounded, cinematic, documentary-style.
2. An animated gradient "commission card" (`components/ImagePromptCard.tsx`) that
   stands in for the artwork today, with a **Copy image prompt** button.

To finish the visuals:

1. Run each `imagePrompt` through Midjourney, DALL·E, Firefly, or your generator
   of choice.
2. Save the result to `/public/images/chapters/{slug}.jpg` (slugs are in
   `lib/chapters.ts`, e.g. `the-road-to-bebeji.jpg`).
3. Swap `<ImagePromptCard>` for a plain `next/image` — the exact replacement
   snippet is commented at the bottom of `components/ImagePromptCard.tsx`.

Alternatively, once real images exist in Firebase Storage, wire the `/admin →
Gallery` tab to write `gallery/{imageId}` documents and have chapter pages read
from Firestore instead of the static prompt.

## Getting started

```bash
npm install
cp .env.local.example .env.local   # fill in your Firebase project keys
npm run dev
```

Open http://localhost:3000.

## Firestore collections (for the CMS)

```
chapters/{slug}        -> editable chapter copy, overrides lib/chapters.ts
gallery/{imageId}       -> { url, caption, chapterSlug, credit }
familyTree/{personId}   -> { name, parentId, birthYear, note, photoUrl }
news/{postId}           -> { title, body, publishedAt, coverUrl }
documents/{docId}       -> { title, fileUrl, description }
messages/{messageId}    -> contact form submissions
```

Storage layout: `/gallery/{chapterSlug}/…`, `/family-tree/{personId}/…`, `/documents/…`.

## Admin dashboard (`/admin`)

Firebase Auth (email/password) sign-in is fully wired. The tab shell for
Chapters / Gallery / Family Tree / News / Documents is in place in
`app/admin/page.tsx`; each tab needs its list + form view added against the
collections above (a short `getDocs`/`addDoc`/`uploadBytes` pattern using
`lib/firebase.ts`). Create your first admin user in the Firebase console under
Authentication, restrict `/admin` further with Firestore security rules keyed to
an `admins` collection before going live.

## Wiring up the animated map

`app/maps/page.tsx` currently renders the route (`lib/chapters.ts` →
`journeyRoute`) as a styled list with real coordinates. For a fully animated map:

- Drop in `react-simple-maps` (SVG, no API key, easiest) or Mapbox GL JS
  (`react-map-gl`, needs a Mapbox token) and plot `journeyRoute` as markers with
  an animated dashed polyline between them.
- Framer Motion's `pathLength` animation works well for "drawing" the migration
  route on scroll.

## Extending: Three.js / GSAP

`three`, `@react-three/fiber`, `@react-three/drei`, and `gsap` are included in
`package.json` for a hero-section upgrade (e.g. a subtle parallax savannah scene
or a GSAP-pinned scrollytelling sequence per chapter) — not wired in yet, since
the current CSS/Framer Motion hero already meets the brief without the extra
bundle weight. Add them chapter-by-chapter where the payoff is worth it.

## Deployment

1. Push to GitHub.
2. Import into Vercel (recommended for Next.js) or any Node host.
3. Add the `.env.local` variables as project environment variables.
4. In Firebase console: enable Authentication (email/password), Firestore, and
   Storage; set security rules so only authenticated admins can write.
5. Set your real domain, then update `SITE_URL` in `app/layout.tsx`,
   `app/sitemap.ts`, and `app/robots.ts`.

## Project structure

```
app/                  Next.js App Router pages (one folder per route)
  chapters/[slug]/    Dynamic chapter page
  admin/              Auth-gated CMS shell
components/           Navbar, Footer, Hero, Timeline, FamilyTree, ImagePromptCard…
lib/
  chapters.ts         All book content: prologue, 10 chapters, epilogue
  firebase.ts         Client SDK + Firestore collection map
  firebase-admin.ts    Server SDK for admin routes
public/images/         Drop real chapter artwork here once generated
```
