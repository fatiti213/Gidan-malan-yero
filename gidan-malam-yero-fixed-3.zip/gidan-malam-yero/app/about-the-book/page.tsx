import type { Metadata } from "next";
import ImagePromptCard from "@/components/ImagePromptCard";

export const metadata: Metadata = {
  title: "About the Book",
  description: "About Gidan Malam Yero: The Yeros — Footprints in the Sand of Time."
};

export default function AboutBookPage() {
  return (
    <div className="pt-32 pb-24">
      <div className="container-editorial grid md:grid-cols-12 gap-10">
        <div className="md:col-span-5">
          <p className="chapter-eyebrow">The Book</p>
          <h1 className="font-display text-5xl mt-3 text-balance">
            Gidan Malam Yero: The Yeros
          </h1>
          <p className="font-display italic text-2xl text-gold mt-2">Footprints in the Sand of Time</p>
          <p className="mt-6 text-lg leading-relaxed text-charcoal/80 dark:text-warmwhite/80">
            A family history that follows the Yeros from the Islamic scholars of Futa Toro,
            through the upheaval of the Fulani jihad in Bebeji, to the founding of the
            family in Zaria City by Malam Ahmad Yero — and onward into the family's faith,
            education, culture, and service to Nigeria today.
          </p>
        </div>
        <div className="md:col-span-6 md:col-start-7">
          <ImagePromptCard
            prompt="A closed hardcover family history book titled GIDAN MALAM YERO — The Yeros — Footprints in the Sand of Time, resting on a woven mat beside an antique compass and a sepia photograph, warm museum lighting, editorial still life photography, 8k."
            label="Cover concept"
            aspect="aspect-[4/5]"
          />
        </div>
      </div>

      <div className="container-editorial mt-24 grid md:grid-cols-3 gap-10 border-t border-charcoal/10 dark:border-warmwhite/10 pt-16">
        <div>
          <p className="font-display text-4xl text-gold">12</p>
          <p className="mt-2 text-sm text-charcoal/70 dark:text-warmwhite/70">
            Sections — a Prologue, ten chapters, and an Epilogue
          </p>
        </div>
        <div>
          <p className="font-display text-4xl text-gold">6</p>
          <p className="mt-2 text-sm text-charcoal/70 dark:text-warmwhite/70">
            Centuries of history, from Futa Toro to the present day
          </p>
        </div>
        <div>
          <p className="font-display text-4xl text-gold">1</p>
          <p className="mt-2 text-sm text-charcoal/70 dark:text-warmwhite/70">
            Founding patriarch — Malam Ahmad Yero of Zaria City
          </p>
        </div>
      </div>
    </div>
  );
}
