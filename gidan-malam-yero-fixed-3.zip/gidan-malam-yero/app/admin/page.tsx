"use client";

import { useEffect, useState } from "react";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, type User } from "firebase/auth";
import { auth } from "@/lib/firebase";

/**
 * Admin dashboard shell.
 *
 * This gives you working Firebase Auth (email/password) gating and the
 * layout for a CMS. The actual editors (chapters, gallery uploads, family
 * tree nodes, news posts) are stubbed as tabs below — each one is a short
 * Firestore read/write against the collections documented in
 * lib/firebase.ts. Wire them up as your content needs solidify; this file
 * is intentionally the seam where you'll spend most of your next session.
 */
export default function AdminPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"chapters" | "gallery" | "family-tree" | "news" | "documents">("chapters");

  useEffect(() => onAuthStateChanged(auth, (u) => { setUser(u); setLoading(false); }), []);

  const login = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch {
      setError("Invalid email or password.");
    }
  };

  if (loading) return <div className="container-editorial pt-40 pb-24">Loading…</div>;

  if (!user) {
    return (
      <div className="container-editorial pt-40 pb-24 max-w-sm">
        <h1 className="font-display text-3xl mb-6">Admin sign in</h1>
        <form onSubmit={login} className="space-y-5">
          <input
            type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)}
            className="w-full border-b border-charcoal/20 bg-transparent py-2 focus:outline-none focus:border-gold"
          />
          <input
            type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="w-full border-b border-charcoal/20 bg-transparent py-2 focus:outline-none focus:border-gold"
          />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button className="rounded-full bg-gold px-6 py-2.5 text-charcoal font-medium">Sign in</button>
        </form>
        <p className="mt-6 text-xs text-charcoal/50">
          Create admin users in the Firebase console under Authentication, or via a
          one-off script using firebase-admin.
        </p>
      </div>
    );
  }

  const tabs: { id: typeof tab; label: string; collection: string }[] = [
    { id: "chapters", label: "Chapters", collection: "chapters/{slug}" },
    { id: "gallery", label: "Gallery", collection: "gallery/{imageId}" },
    { id: "family-tree", label: "Family Tree", collection: "familyTree/{personId}" },
    { id: "news", label: "News", collection: "news/{postId}" },
    { id: "documents", label: "Documents", collection: "documents/{docId}" }
  ];

  return (
    <div className="container-editorial pt-40 pb-24">
      <div className="flex items-center justify-between mb-10">
        <h1 className="font-display text-3xl">Admin Dashboard</h1>
        <button onClick={() => signOut(auth)} className="text-sm underline">Sign out</button>
      </div>

      <div className="flex gap-2 border-b border-charcoal/10 mb-10 flex-wrap">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm ${tab === t.id ? "border-b-2 border-gold text-gold" : "text-charcoal/60"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="rounded-sm border border-dashed border-charcoal/20 p-10 text-sm text-charcoal/60">
        <p>
          Editor for <code>{tabs.find((t) => t.id === tab)?.collection}</code> goes here — a
          list view plus a form using <code>lib/firebase.ts</code>'s <code>db</code> and{" "}
          <code>storage</code>. Follow the pattern: <code>collection(db, "…")</code>,{" "}
          <code>addDoc</code> / <code>updateDoc</code>, and <code>uploadBytes</code> for
          images/documents.
        </p>
      </div>
    </div>
  );
}
