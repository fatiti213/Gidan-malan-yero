import type { Metadata } from "next";
import ImagePromptCard from "@/components/ImagePromptCard";

export const metadata: Metadata = {
  title: "Meet the Author",
  description: "The author behind Gidan Malam Yero: The Yeros — Footprints in the Sand of Time."
};

export default function AuthorPage() {
  return (
    <div className="container-editorial pt-32 pb-24 grid md:grid-cols-12 gap-10">
      <div className="md:col-span-4">
        <ImagePromptCard
          prompt="Warm editorial portrait of a Nigerian author seated at a wooden writing desk with an open manuscript and a cup of tea, soft window light, bookshelf with historical texts in the background, documentary portrait photography style, respectful and dignified, 8k."
          label="Author portrait"
          aspect="aspect-[4/5]"
        />
      </div>
      <div className="md:col-span-7 md:col-start-6">
        <p className="chapter-eyebrow">Meet the Author</p>
        <h1 className="font-display text-5xl mt-3 text-balance">The voice behind the Yeros</h1>
        <p className="mt-6 text-lg leading-relaxed text-charcoal/80 dark:text-warmwhite/80">
          Replace this placeholder with the author's biography, photograph, and note on
          why this history was written — sourced from family archives, oral history, and
          the manuscript itself. Manage this copy through the admin dashboard's
          &ldquo;Author&rdquo; document.
        </p>
      </div>
    </div>
  );
}
