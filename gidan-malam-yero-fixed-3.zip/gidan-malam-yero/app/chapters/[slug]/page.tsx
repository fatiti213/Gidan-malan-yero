import { chapters, getChapterBySlug } from "@/lib/chapters";
import ImagePromptCard from "@/components/ImagePromptCard";
import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, MapPin } from "lucide-react";

export function generateStaticParams() {
  return chapters.map((c) => ({ slug: c.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const chapter = getChapterBySlug(params.slug);
  if (!chapter) return {};
  return {
    title: chapter.title,
    description: chapter.dek,
    openGraph: { title: chapter.title, description: chapter.dek }
  };
}

export default function ChapterPage({ params }: { params: { slug: string } }) {
  const chapter = getChapterBySlug(params.slug);
  if (!chapter) return notFound();

  const index = chapters.findIndex((c) => c.slug === chapter.slug);
  const prev = chapters[index - 1];
  const next = chapters[index + 1];

  const kicker =
    chapter.kind === "chapter" ? `Chapter ${chapter.number}` : chapter.kind === "prologue" ? "Prologue" : "Epilogue";

  return (
    <article>
      {/* Chapter hero */}
      <section className="relative h-[70svh] min-h-[440px] w-full overflow-hidden">
        <ImagePromptCard prompt={chapter.imagePrompt} label={chapter.title} aspect="h-full" />
        <div className="absolute inset-0 flex flex-col justify-end pointer-events-none">
          <div className="container-editorial pb-14">
            <p className="chapter-eyebrow text-gold-bright">{kicker}{chapter.years ? ` · ${chapter.years}` : ""}</p>
            <h1 className="font-display text-warmwhite text-5xl md:text-7xl mt-3 text-balance max-w-3xl">
              {chapter.title}
            </h1>
            {chapter.location && (
              <p className="mt-4 flex items-center gap-2 text-warmwhite/70 text-sm">
                <MapPin size={14} /> {chapter.location}
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Body */}
      <section className="container-editorial py-20 grid md:grid-cols-12 gap-10">
        <div className="md:col-span-3">
          <div className="sticky top-28 space-y-8">
            <div>
              <p className="chapter-eyebrow mb-2">In this chapter</p>
              <p className="text-charcoal/70 dark:text-warmwhite/70 text-sm">{chapter.dek}</p>
            </div>
            {chapter.facts.length > 0 && (
              <div>
                <p className="chapter-eyebrow mb-3">Historical notes</p>
                <ul className="space-y-3">
                  {chapter.facts.map((f) => (
                    <li key={f} className="text-sm text-charcoal/70 dark:text-warmwhite/70 border-l-2 border-gold/50 pl-3">
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        <div className="md:col-span-8 md:col-start-5 prose-yero">
          {chapter.paragraphs.map((p, i) => (
            <p key={i} className={i === 0 ? "chapter-first-letter" : ""}>
              {p}
            </p>
          ))}

          <blockquote className="my-12 border-l-4 border-gold pl-6 py-2">
            <p className="font-display italic text-2xl md:text-3xl text-balance leading-snug">
              &ldquo;{chapter.quote}&rdquo;
            </p>
          </blockquote>
        </div>
      </section>

      {/* Prev / Next */}
      <nav className="border-t border-charcoal/10 dark:border-warmwhite/10">
        <div className="container-editorial grid grid-cols-2">
          <div className="py-10 pr-6">
            {prev ? (
              <Link href={`/chapters/${prev.slug}`} className="group flex flex-col items-start gap-2">
                <span className="flex items-center gap-2 text-xs text-charcoal/50 dark:text-warmwhite/50">
                  <ArrowLeft size={13} /> Previous
                </span>
                <span className="font-display text-xl group-hover:text-gold transition-colors">{prev.title}</span>
              </Link>
            ) : (
              <span />
            )}
          </div>
          <div className="py-10 pl-6 text-right border-l border-charcoal/10 dark:border-warmwhite/10">
            {next ? (
              <Link href={`/chapters/${next.slug}`} className="group flex flex-col items-end gap-2">
                <span className="flex items-center gap-2 text-xs text-charcoal/50 dark:text-warmwhite/50">
                  Next <ArrowRight size={13} />
                </span>
                <span className="font-display text-xl group-hover:text-gold transition-colors">{next.title}</span>
              </Link>
            ) : (
              <span />
            )}
          </div>
        </div>
      </nav>
    </article>
  );
}
