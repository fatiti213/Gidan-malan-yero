import Link from "next/link";
import type { Metadata } from "next";
import ImagePromptCard from "@/components/ImagePromptCard";
import { chapters } from "@/lib/chapters";

export const metadata: Metadata = {
  title: "The Journey — All Chapters",
  description: "Every chapter of Gidan Malam Yero, from the Prologue in Futa Toro to the Epilogue in modern Nigeria."
};

export default function ChaptersPage() {
  return (
    <div className="container-editorial pt-32 pb-24">
      <p className="chapter-eyebrow">The Full Story</p>
      <h1 className="font-display text-5xl md:text-6xl mt-3 text-balance">Every chapter</h1>
      <p className="mt-4 max-w-xl text-charcoal/70 dark:text-warmwhite/70">
        Eleven chapters, one migration — from the Islamic scholars of Futa Toro to the
        legacy the Yeros carry today.
      </p>

      <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-10">
        {chapters.map((c) => (
          <Link key={c.slug} href={`/chapters/${c.slug}`} className="group block">
            <ImagePromptCard prompt={c.imagePrompt} label={c.title} />
            <p className="chapter-eyebrow mt-4">
              {c.kind === "chapter" ? `Chapter ${c.number}` : c.kind === "prologue" ? "Prologue" : "Epilogue"}
              {c.years ? ` · ${c.years}` : ""}
            </p>
            <h2 className="font-display text-2xl mt-1 group-hover:text-gold transition-colors">{c.title}</h2>
            <p className="text-sm text-charcoal/65 dark:text-warmwhite/65 mt-2">{c.dek}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
