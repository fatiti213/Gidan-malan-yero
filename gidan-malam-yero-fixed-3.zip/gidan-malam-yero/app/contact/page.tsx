"use client";

import { useState } from "react";
import { motion } from "framer-motion";

export default function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <div className="container-editorial pt-32 pb-24 max-w-xl">
      <p className="chapter-eyebrow">Get in Touch</p>
      <h1 className="font-display text-5xl mt-3 text-balance">Contact the Family</h1>
      <p className="mt-4 text-charcoal/70 dark:text-warmwhite/70">
        A descendant, a historian, or simply moved by the story — we'd like to hear from
        you. Messages are stored in Firestore's <code>messages</code> collection for the
        family to review from the admin dashboard.
      </p>

      {sent ? (
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-10 rounded-sm border border-emerald/40 bg-emerald/10 p-6 text-emerald dark:text-emerald-light"
        >
          Thank you — your message has been received.
        </motion.p>
      ) : (
        <form
          className="mt-10 space-y-6"
          onSubmit={(e) => {
            e.preventDefault();
            // TODO: wire to a Firestore write or /api/contact route using lib/firebase.ts
            setSent(true);
          }}
        >
          <div>
            <label className="text-xs uppercase tracking-widest2 text-charcoal/60 dark:text-warmwhite/60">Name</label>
            <input required className="mt-2 w-full border-b border-charcoal/20 dark:border-warmwhite/20 bg-transparent py-2 focus:outline-none focus:border-gold" />
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest2 text-charcoal/60 dark:text-warmwhite/60">Email</label>
            <input required type="email" className="mt-2 w-full border-b border-charcoal/20 dark:border-warmwhite/20 bg-transparent py-2 focus:outline-none focus:border-gold" />
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest2 text-charcoal/60 dark:text-warmwhite/60">Message</label>
            <textarea required rows={5} className="mt-2 w-full border-b border-charcoal/20 dark:border-warmwhite/20 bg-transparent py-2 focus:outline-none focus:border-gold" />
          </div>
          <button type="submit" className="rounded-full bg-gold px-8 py-3 text-charcoal font-medium hover:bg-gold-bright transition-colors">
            Send Message
          </button>
        </form>
      )}
    </div>
  );
}
