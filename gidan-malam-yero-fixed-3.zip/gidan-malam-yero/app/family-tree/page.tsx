import type { Metadata } from "next";
import FamilyTree from "@/components/FamilyTree";

export const metadata: Metadata = {
  title: "Family Tree",
  description: "The Yero family tree, beginning with Malam Ahmad Yero of Zaria City."
};

export default function FamilyTreePage() {
  return (
    <div className="container-editorial pt-32 pb-24">
      <p className="chapter-eyebrow">Lineage</p>
      <h1 className="font-display text-5xl mt-3 text-balance">The Family Tree</h1>
      <p className="mt-4 max-w-xl text-charcoal/70 dark:text-warmwhite/70">
        Beginning with Malam Ahmad Yero, patriarch of Zaria City. Tap a name to expand
        its branch. New generations are added by the family through the admin dashboard.
      </p>

      <div className="mt-14">
        <FamilyTree />
      </div>
    </div>
  );
}
