import type { Metadata } from "next";
import ImagePromptCard from "@/components/ImagePromptCard";
import { chapters } from "@/lib/chapters";

export const metadata: Metadata = {
  title: "Gallery",
  description: "Illustration briefs and imagery for every chapter of Gidan Malam Yero."
};

export default function GalleryPage() {
  return (
    <div className="container-editorial pt-32 pb-24">
      <p className="chapter-eyebrow">Visual Archive</p>
      <h1 className="font-display text-5xl mt-3 text-balance">Gallery</h1>
      <p className="mt-4 max-w-2xl text-charcoal/70 dark:text-warmwhite/70">
        Each chapter carries a commissioned illustration brief below. Run a brief through
        your image generator of choice, then upload the result via the admin dashboard —
        it will automatically replace the placeholder here and across the site.
      </p>

      <div className="mt-14 columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
        {chapters.map((c) => (
          <div key={c.slug} className="break-inside-avoid">
            <ImagePromptCard prompt={c.imagePrompt} label={c.title} aspect="aspect-[4/5]" />
            <p className="mt-3 font-display text-lg">{c.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
