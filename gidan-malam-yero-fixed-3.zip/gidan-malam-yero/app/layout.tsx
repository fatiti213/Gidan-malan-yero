import type { Metadata } from "next";
import { Fraunces, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SmoothScroll from "@/components/SmoothScroll";

const fraunces = Fraunces({ subsets: ["latin"], variable: "--font-fraunces", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const mono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500"], variable: "--font-mono", display: "swap" });

const SITE_URL = "https://gidanmalamyero.family";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "Gidan Malam Yero — The Yeros: Footprints in the Sand of Time",
    template: "%s · Gidan Malam Yero"
  },
  description:
    "The cinematic family history of the Yeros — from Futa Toro and Bebeji to Zaria City. An interactive timeline, family tree, maps, and the full story of a family that became a bridge between worlds.",
  keywords: [
    "Gidan Malam Yero",
    "Yero family history",
    "Futa Toro",
    "Toronkawa",
    "Zaria City history",
    "Fulani Hausa family",
    "Ahmad Yero",
    "Nigerian family history book"
  ],
  openGraph: {
    title: "Gidan Malam Yero — The Yeros: Footprints in the Sand of Time",
    description:
      "A cinematic family history spanning Futa Toro, Bebeji, and Zaria City — told through an interactive timeline, family tree, and maps.",
    url: SITE_URL,
    siteName: "Gidan Malam Yero",
    type: "website",
    images: [{ url: "/images/og-cover.jpg", width: 1200, height: 630 }]
  },
  twitter: {
    card: "summary_large_image",
    title: "Gidan Malam Yero — The Yeros",
    description: "Footprints in the Sand of Time — a family history."
  },
  robots: { index: true, follow: true }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${fraunces.variable} ${inter.variable} ${mono.variable} font-body`}>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Book",
              name: "Gidan Malam Yero: The Yeros — Footprints in the Sand of Time",
              about: "Family history of the Yero family from Futa Toro to Zaria City, Nigeria",
              genre: "Family history"
            })
          }}
        />
        <SmoothScroll>
          <Navbar />
          <main>{children}</main>
          <Footer />
        </SmoothScroll>
      </body>
    </html>
  );
}
