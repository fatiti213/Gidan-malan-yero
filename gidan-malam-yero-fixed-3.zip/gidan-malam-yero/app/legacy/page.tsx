import type { Metadata } from "next";
import ImagePromptCard from "@/components/ImagePromptCard";
import { getChapterBySlug } from "@/lib/chapters";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Legacy",
  description: "The legacy of unity that defines the Yero family."
};

export default function LegacyPage() {
  const legacy = getChapterBySlug("the-legacy-of-unity")!;
  const epilogue = getChapterBySlug("epilogue")!;

  return (
    <div className="pt-32 pb-24">
      <div className="container-editorial">
        <p className="chapter-eyebrow">What Endures</p>
        <h1 className="font-display text-5xl mt-3 text-balance">Legacy</h1>
      </div>

      <div className="container-editorial mt-16 grid md:grid-cols-2 gap-10">
        {[legacy, epilogue].map((c) => (
          <Link key={c.slug} href={`/chapters/${c.slug}`} className="group block">
            <ImagePromptCard prompt={c.imagePrompt} label={c.title} aspect="aspect-[4/3]" />
            <p className="chapter-eyebrow mt-4">{c.title}</p>
            <p className="font-display italic text-xl mt-2 text-balance group-hover:text-gold transition-colors">
              &ldquo;{c.quote}&rdquo;
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
