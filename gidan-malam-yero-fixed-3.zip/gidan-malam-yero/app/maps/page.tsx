import type { Metadata } from "next";
import { journeyRoute } from "@/lib/chapters";
import { MapPin } from "lucide-react";

export const metadata: Metadata = {
  title: "Maps",
  description: "The migration route of the Yero family across West Africa."
};

export default function MapsPage() {
  return (
    <div className="container-editorial pt-32 pb-24">
      <p className="chapter-eyebrow">Geography</p>
      <h1 className="font-display text-5xl mt-3 text-balance">The Migration Route</h1>
      <p className="mt-4 max-w-xl text-charcoal/70 dark:text-warmwhite/70">
        From Futa Toro on the Senegal and Gambia rivers, to Bebeji under the Kano
        Emirate, to Zaria City in the Zazzau Emirate, and into modern Nigeria.
      </p>

      <div className="mt-16 rounded-sm border border-charcoal/10 dark:border-warmwhite/10 bg-sand-light dark:bg-charcoal-soft p-6 md:p-10">
        <p className="font-mono text-[11px] uppercase tracking-widest2 text-charcoal/50 dark:text-warmwhite/50 mb-8">
          Route data below is ready to drop into a Mapbox / Google Maps / react-simple-maps
          component for a fully animated map — see README &rarr; &ldquo;Wiring up the animated
          map&rdquo;.
        </p>
        <ol className="relative border-l border-dashed border-gold/50 pl-8 space-y-10">
          {journeyRoute.map((stop) => (
            <li key={stop.label} className="relative">
              <span className="absolute -left-[38px] top-1 flex h-6 w-6 items-center justify-center rounded-full bg-gold text-charcoal">
                <MapPin size={13} />
              </span>
              <p className="font-display text-2xl">{stop.label}</p>
              <p className="font-mono text-xs uppercase tracking-widest2 text-emerald dark:text-emerald-light mt-1">
                {stop.era}
              </p>
              <p className="text-xs text-charcoal/50 dark:text-warmwhite/50 mt-1">
                {stop.coordinates.lat.toFixed(2)}, {stop.coordinates.lng.toFixed(2)}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
