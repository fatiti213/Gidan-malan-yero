import Hero from "@/components/Hero";
import Link from "next/link";
import ImagePromptCard from "@/components/ImagePromptCard";
import { chapters, journeyRoute } from "@/lib/chapters";

export default function HomePage() {
  return (
    <>
      <Hero />

      {/* Introduction */}
      <section className="container-editorial py-24 md:py-32 grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <p className="chapter-eyebrow">The Book</p>
          <h2 className="font-display text-4xl mt-3 text-balance">A family history</h2>
        </div>
        <div className="md:col-span-7 md:col-start-6">
          <p className="text-xl md:text-2xl font-display leading-relaxed text-charcoal/90 dark:text-warmwhite/90 text-balance">
            From the Islamic scholars of Futa Toro to the courts of Zaria City — this is the
            story of how one family became a bridge between two peoples, two languages,
            and two faiths, without ever losing themselves.
          </p>
          <Link
            href="/about-the-book"
            className="inline-block mt-8 text-sm font-medium border-b border-gold pb-1 hover:text-gold transition-colors"
          >
            Read about the book
          </Link>
        </div>
      </section>

      {/* Journey route strip */}
      <section className="bg-brown text-warmwhite py-20">
        <div className="container-editorial">
          <p className="chapter-eyebrow text-gold-bright">The Route</p>
          <h2 className="font-display text-3xl md:text-4xl mt-3 mb-12">Six centuries, one migration</h2>
          <div className="footprint-trail flex-wrap gap-y-6">
            {journeyRoute.map((stop, i) => (
              <div key={stop.label} className="flex items-center gap-3">
                {i > 0 && <span className="hidden md:block" />}
                <div>
                  <p className="font-display text-lg">{stop.label}</p>
                  <p className="font-mono text-[11px] uppercase tracking-widest2 text-warmwhite/50">{stop.era}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Chapter grid */}
      <section className="container-editorial py-24 md:py-32">
        <div className="flex items-end justify-between mb-12 flex-wrap gap-4">
          <div>
            <p className="chapter-eyebrow">Chapter by chapter</p>
            <h2 className="font-display text-4xl mt-3">Begin the journey</h2>
          </div>
          <Link href="/chapters" className="text-sm border-b border-gold pb-1 hover:text-gold transition-colors">
            View all chapters
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {chapters.map((c) => (
            <Link key={c.slug} href={`/chapters/${c.slug}`} className="group block">
              <ImagePromptCard prompt={c.imagePrompt} label={c.title} />
              <p className="chapter-eyebrow mt-4">
                {c.kind === "chapter" ? `Chapter ${c.number}` : c.kind === "prologue" ? "Prologue" : "Epilogue"}
              </p>
              <h3 className="font-display text-2xl mt-1 group-hover:text-gold transition-colors">{c.title}</h3>
              <p className="text-sm text-charcoal/65 dark:text-warmwhite/65 mt-2">{c.dek}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-emerald text-warmwhite py-24">
        <div className="container-editorial text-center max-w-2xl mx-auto">
          <h2 className="font-display text-4xl md:text-5xl text-balance">
            Explore the family tree, from Malam Ahmad Yero onward
          </h2>
          <Link
            href="/family-tree"
            className="inline-block mt-8 rounded-full bg-gold text-charcoal px-8 py-3.5 font-medium hover:bg-gold-bright transition-colors"
          >
            View the Family Tree
          </Link>
        </div>
      </section>
    </>
  );
}
