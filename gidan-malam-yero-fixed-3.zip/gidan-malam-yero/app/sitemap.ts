import type { MetadataRoute } from "next";
import { chapters } from "@/lib/chapters";

const SITE_URL = "https://gidanmalamyero.family";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = [
    "",
    "/about-the-book",
    "/chapters",
    "/family-tree",
    "/timeline",
    "/gallery",
    "/maps",
    "/legacy",
    "/author",
    "/contact"
  ].map((path) => ({
    url: `${SITE_URL}${path}`,
    lastModified: new Date(),
    changeFrequency: "monthly" as const,
    priority: path === "" ? 1 : 0.7
  }));

  const chapterRoutes = chapters.map((c) => ({
    url: `${SITE_URL}/chapters/${c.slug}`,
    lastModified: new Date(),
    changeFrequency: "yearly" as const,
    priority: 0.8
  }));

  return [...staticRoutes, ...chapterRoutes];
}
