import type { Metadata } from "next";
import Timeline from "@/components/Timeline";

export const metadata: Metadata = {
  title: "Interactive Timeline",
  description: "The Yero family's journey through history, from Futa Toro to modern Nigeria."
};

export default function TimelinePage() {
  return (
    <div className="container-editorial pt-32 pb-24">
      <p className="chapter-eyebrow">Six Centuries</p>
      <h1 className="font-display text-5xl mt-3 text-balance">The Timeline</h1>
      <p className="mt-4 max-w-xl text-charcoal/70 dark:text-warmwhite/70">
        From the Islamic scholars of Futa Toro to the Yeros of today — every chapter,
        in order.
      </p>
      <div className="mt-20">
        <Timeline />
      </div>
    </div>
  );
}
