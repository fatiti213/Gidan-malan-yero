"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus, User } from "lucide-react";

export type FamilyNode = {
  id: string;
  name: string;
  note?: string;
  children?: FamilyNode[];
};

// Seed data. In production this is loaded from Firestore's `familyTree`
// collection (see lib/firebase.ts) so new generations can be added through
// the /admin dashboard without touching code.
export const familySeed: FamilyNode = {
  id: "ahmad-yero",
  name: "Malam Ahmad Yero",
  note: "Founding patriarch · Zaria City, mid-19th century",
  children: [
    {
      id: "gen-2",
      name: "Second Generation",
      note: "Children of Malam Ahmad Yero",
      children: [
        { id: "gen-3a", name: "Third Generation — Branch A", note: "Add descendants via /admin" },
        { id: "gen-3b", name: "Third Generation — Branch B", note: "Add descendants via /admin" }
      ]
    }
  ]
};

function TreeNode({ node, depth = 0 }: { node: FamilyNode; depth?: number }) {
  const [expanded, setExpanded] = useState(depth < 1);
  const hasChildren = !!node.children?.length;

  return (
    <div className="relative">
      <motion.div
        initial={{ opacity: 0, x: -8 }}
        animate={{ opacity: 1, x: 0 }}
        className="flex items-start gap-3 py-2.5"
        style={{ paddingLeft: depth * 28 }}
      >
        <button
          onClick={() => hasChildren && setExpanded((e) => !e)}
          className={`mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${
            hasChildren ? "border-gold text-gold cursor-pointer" : "border-charcoal/20 text-charcoal/30 dark:border-warmwhite/20"
          }`}
          aria-label={hasChildren ? (expanded ? "Collapse" : "Expand") : undefined}
        >
          {hasChildren ? expanded ? <Minus size={12} /> : <Plus size={12} /> : <User size={11} />}
        </button>
        <div>
          <p className="font-display text-lg leading-snug">{node.name}</p>
          {node.note && <p className="text-xs text-charcoal/60 dark:text-warmwhite/60 mt-0.5">{node.note}</p>}
        </div>
      </motion.div>

      <AnimatePresence>
        {hasChildren && expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-l border-dashed border-gold/40 ml-3"
          >
            {node.children!.map((child) => (
              <TreeNode key={child.id} node={child} depth={depth + 1} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FamilyTree({ root = familySeed }: { root?: FamilyNode }) {
  return (
    <div className="rounded-sm border border-charcoal/10 dark:border-warmwhite/10 bg-warmwhite/60 dark:bg-charcoal-soft/60 p-6 md:p-10">
      <TreeNode node={root} />
    </div>
  );
}
