import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-brown-deep text-warmwhite/80">
      <div className="container-editorial py-16 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div>
          <p className="font-display text-xl text-warmwhite">GIDAN MALAM YERO</p>
          <p className="font-mono text-xs tracking-widest2 uppercase text-gold-bright/80 mt-2">
            Footprints in the Sand of Time
          </p>
          <p className="mt-4 text-sm text-warmwhite/60 max-w-xs">
            A family history spanning Futa Toro, Bebeji, and Zaria — told for every
            generation of the Yeros still to come.
          </p>
        </div>

        <div>
          <p className="text-xs uppercase tracking-widest2 text-gold-bright/70 mb-4">Explore</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/chapters">The Journey</Link></li>
            <li><Link href="/family-tree">Family Tree</Link></li>
            <li><Link href="/timeline">Timeline</Link></li>
            <li><Link href="/maps">Maps</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-xs uppercase tracking-widest2 text-gold-bright/70 mb-4">The Book</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/about-the-book">About the Book</Link></li>
            <li><Link href="/author">Meet the Author</Link></li>
            <li><Link href="/legacy">Legacy</Link></li>
            <li><Link href="/gallery">Gallery</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-xs uppercase tracking-widest2 text-gold-bright/70 mb-4">Connect</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/contact">Contact the Family</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-warmwhite/10">
        <div className="container-editorial py-6 flex flex-col md:flex-row justify-between gap-2 text-xs text-warmwhite/40">
          <p>&copy; {new Date().getFullYear()} The Yero Family. All rights reserved.</p>
          <p>Their footprint will never be erased from the sand of time.</p>
        </div>
      </div>
    </footer>
  );
}
