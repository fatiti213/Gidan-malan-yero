"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ChevronDown } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative h-[100svh] min-h-[640px] w-full overflow-hidden bg-charcoal">
      {/* Savannah-at-sunrise field, built in CSS gradients + drift animation
          (swap for a full-bleed <video> or <Image> at /public/images/hero.jpg
          once the commissioned illustration is ready — see README). */}
      <motion.div
        className="absolute inset-0 bg-[radial-gradient(140%_100%_at_50%_100%,#E0B24E_0%,#C89B3C_18%,#7a4a1f_38%,#3E2723_60%,#1A1A1A_100%)] animate-drift bg-[length:150%_150%]"
        aria-hidden
      />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/30 to-charcoal/10" />
      <div className="grain-overlay" />

      {/* Silhouette baobab + savannah grass line */}
      <svg
        className="absolute bottom-0 left-0 w-full text-charcoal"
        viewBox="0 0 1440 220"
        preserveAspectRatio="none"
        aria-hidden
      >
        <path
          fill="currentColor"
          d="M0,140 C240,180 360,90 520,120 C680,150 760,60 900,90 C1040,120 1160,170 1440,130 L1440,220 L0,220 Z"
        />
      </svg>

      <div className="relative z-10 h-full container-editorial flex flex-col items-center justify-center text-center">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="font-mono text-xs md:text-sm tracking-widest2 uppercase text-gold-bright/90 mb-6"
        >
          A Family History &middot; Futa Toro to Zaria
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.15 }}
          className="font-display text-warmwhite text-balance text-5xl sm:text-6xl md:text-8xl leading-[0.95]"
        >
          GIDAN MALAM
          <br />
          YERO
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.3 }}
          className="mt-6 font-display italic text-2xl md:text-4xl text-gold-bright"
        >
          The Yeros
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.42 }}
          className="mt-4 text-warmwhite/70 tracking-wide text-sm md:text-base uppercase"
        >
          Footprints in the Sand of Time
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.6 }}
          className="mt-10"
        >
          <Link
            href="/chapters/prologue"
            className="inline-flex items-center gap-3 rounded-full bg-gold px-8 py-3.5 text-charcoal font-medium tracking-wide hover:bg-gold-bright transition-colors"
          >
            Begin the Journey
          </Link>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-warmwhite/60 animate-footstep"
      >
        <ChevronDown size={22} />
      </motion.div>
    </section>
  );
}
