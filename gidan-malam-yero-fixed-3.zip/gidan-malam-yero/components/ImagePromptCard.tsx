"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Copy, Check, Image as ImageIcon } from "lucide-react";

/**
 * Placeholder "commission plate" for chapter artwork.
 *
 * This project does not call an image-generation model, so no chapter
 * image is rendered as a pixel file. Instead each chapter gets a
 * cinematic gradient canvas plus its full illustration brief, ready to
 * paste into Midjourney / DALL·E / Firefly. Once you have a real file,
 * drop it in /public/images/chapters/{slug}.jpg and swap this component
 * for a plain <Image> — the layout, caption, and credit line are already
 * built to accept one (see the commented block below).
 */
export default function ImagePromptCard({
  prompt,
  label,
  aspect = "aspect-[16/9]"
}: {
  prompt: string;
  label: string;
  aspect?: string;
}) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className={`relative w-full ${aspect} overflow-hidden rounded-sm group`}>
      {/* Animated savannah-toned gradient standing in for the illustration */}
      <motion.div
        className="absolute inset-0 bg-[radial-gradient(120%_120%_at_15%_10%,#E0B24E_0%,#C89B3C_28%,#3E2723_62%,#1A1A1A_100%)] animate-drift bg-[length:160%_160%]"
        aria-hidden
      />
      <div className="grain-overlay" />
      <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/10 to-transparent" />

      <div className="relative h-full flex flex-col justify-between p-5 md:p-7">
        <div className="flex items-center gap-2 text-warmwhite/90">
          <ImageIcon size={14} />
          <span className="font-mono text-[10px] tracking-widest2 uppercase">{label} · illustration brief</span>
        </div>

        <div>
          <p className="text-warmwhite/90 text-xs md:text-sm leading-relaxed line-clamp-4 md:line-clamp-5 font-body">
            {prompt}
          </p>
          <button
            onClick={copy}
            className="mt-4 inline-flex items-center gap-2 rounded-full border border-warmwhite/40 px-4 py-1.5 text-xs text-warmwhite hover:bg-warmwhite hover:text-charcoal transition-colors"
          >
            {copied ? <Check size={13} /> : <Copy size={13} />}
            {copied ? "Prompt copied" : "Copy image prompt"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* Once real artwork exists, replace the render above with:
 *
 * import Image from "next/image";
 * <div className={`relative w-full ${aspect} overflow-hidden rounded-sm`}>
 *   <Image src={`/images/chapters/${slug}.jpg`} alt={label} fill className="object-cover" />
 * </div>
 */
