"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Moon, Sun } from "lucide-react";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/about-the-book", label: "About the Book" },
  { href: "/chapters", label: "The Journey" },
  { href: "/family-tree", label: "Family Tree" },
  { href: "/timeline", label: "Timeline" },
  { href: "/gallery", label: "Gallery" },
  { href: "/maps", label: "Maps" },
  { href: "/legacy", label: "Legacy" },
  { href: "/author", label: "The Author" },
  { href: "/contact", label: "Contact" }
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
        scrolled ? "bg-warmwhite/90 dark:bg-charcoal/90 backdrop-blur-md shadow-[0_1px_0_rgba(0,0,0,0.06)]" : "bg-transparent"
      }`}
    >
      <div className="container-editorial flex h-20 items-center justify-between">
        <Link href="/" className="font-display text-lg tracking-wide">
          <span className="block leading-none">GIDAN MALAM YERO</span>
          <span className="block font-mono text-[10px] tracking-widest2 uppercase text-gold-bright/80 mt-1">
            The Yeros
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-sm font-body text-charcoal/80 dark:text-warmwhite/80 hover:text-gold transition-colors"
            >
              {l.label}
            </Link>
          ))}
          <button
            aria-label="Toggle dark mode"
            onClick={() => setDark((d) => !d)}
            className="rounded-full p-2 border border-charcoal/15 dark:border-warmwhite/20 hover:border-gold transition-colors"
          >
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </nav>

        <button
          className="lg:hidden p-2"
          aria-label="Open menu"
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="lg:hidden overflow-hidden bg-warmwhite dark:bg-charcoal border-t border-charcoal/10 dark:border-warmwhite/10"
          >
            <div className="container-editorial py-6 flex flex-col gap-4">
              {LINKS.map((l) => (
                <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="text-base">
                  {l.label}
                </Link>
              ))}
              <button
                onClick={() => setDark((d) => !d)}
                className="flex items-center gap-2 text-sm text-charcoal/70 dark:text-warmwhite/70"
              >
                {dark ? <Sun size={16} /> : <Moon size={16} />} Toggle dark mode
              </button>
            </div>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
