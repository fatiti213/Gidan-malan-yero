"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { chapters } from "@/lib/chapters";

export default function Timeline() {
  return (
    <div className="relative">
      <div className="absolute left-[15px] md:left-1/2 top-0 bottom-0 w-px bg-charcoal/15 dark:bg-warmwhite/15 md:-translate-x-1/2" />

      <ol className="space-y-14">
        {chapters.map((c, i) => {
          const alignRight = i % 2 === 0;
          return (
            <motion.li
              key={c.slug}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6 }}
              className={`relative pl-10 md:pl-0 md:w-1/2 ${
                alignRight ? "md:ml-0 md:pr-14 md:text-right" : "md:ml-auto md:pl-14"
              }`}
            >
              <span className="absolute left-0 md:left-auto md:right-[calc(50%_-_5px)] top-1.5 h-[10px] w-[10px] rounded-full bg-gold border-2 border-warmwhite dark:border-charcoal"
                style={alignRight ? { right: "-5px", left: "auto" } : {}}
              />
              <p className="chapter-eyebrow">
                {c.kind === "chapter" ? `Chapter ${c.number}` : c.kind === "prologue" ? "Prologue" : "Epilogue"}
                {c.years ? ` · ${c.years}` : ""}
              </p>
              <Link href={`/chapters/${c.slug}`}>
                <h3 className="font-display text-2xl mt-1 hover:text-gold transition-colors">{c.title}</h3>
              </Link>
              <p className="mt-2 text-sm text-charcoal/70 dark:text-warmwhite/70">{c.dek}</p>
              {c.location && (
                <p className="mt-2 font-mono text-[11px] uppercase tracking-widest2 text-emerald dark:text-emerald-light">
                  {c.location}
                </p>
              )}
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
