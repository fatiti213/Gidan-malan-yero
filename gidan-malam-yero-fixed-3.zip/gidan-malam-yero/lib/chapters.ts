export type Chapter = {
  slug: string;
  order: number;
  kind: "prologue" | "chapter" | "epilogue";
  number?: number;
  title: string;
  dek: string;
  years?: string;
  location?: string;
  coordinates?: { lat: number; lng: number };
  paragraphs: string[];
  quote: string;
  imagePrompt: string;
  facts: string[];
};

export const chapters: Chapter[] = [
  {
    slug: "prologue",
    order: 0,
    kind: "prologue",
    title: "The Call of Ancestors",
    dek: "Before borders, before the white man's calendar — the Toronkawa of Futa Toro answer a call on the wind.",
    years: "Before the 16th century",
    location: "Futa Toro (Takrur), Senegal River basin",
    coordinates: { lat: 16.5, lng: -14.0 },
    paragraphs: [
      "In the land where the Senegal and Gambia rivers weave their ancient paths through the golden savanna, there once lived a people whose destiny was written in the stars of the Fulani heavens. The year was long before the coming of the white man's calendar, before the borders of nations scarred the earth, when the Islamic theocratic state of Takrur — known to some as Futa Toro — stood as a beacon of faith and learning in the vast expanse of West Africa.",
      "The Toronkawa clan, scholars and warriors, dreamers and believers, had built their lives around the sacred teachings of Islam. Their children learned the Qur'an before they learned to herd cattle. Their elders spoke of a time when the Prophet's light would guide them to lands unknown, where they would plant the seeds of knowledge in foreign soil.",
      "And so, when the call came — that whisper on the wind that spoke of new horizons, new opportunities, new beginnings — the ancestors of the Yeros answered. They packed their meager belongings, gathered their families, and turned their faces eastward.",
      "They did not know that their journey would span centuries. They did not know that their descendants would become a bridge between worlds, a living testament to the power of faith and identity. They only knew that they must go."
    ],
    quote: "They only knew that they must go.",
    imagePrompt:
      "Cinematic wide shot of ancient Futa Toro at first light: a Fulani scholars' encampment beside the Senegal River, golden savannah grass catching low dawn sun, silhouetted baobab trees, an open-air Islamic learning circle with elders and children seated on woven mats reading from wooden Qur'anic slates, distant cattle herds, warm haze, National Geographic documentary photography style, volumetric light, historically accurate 17th-century West African dress and architecture, ultra-detailed, 8k.",
    facts: [
      "Futa Toro (Takrur) was one of the earliest Islamic states in West Africa.",
      "The Toronkawa were a scholarly Fulani clan centered in the Senegambian basin."
    ]
  },
  {
    slug: "the-road-to-bebeji",
    order: 1,
    kind: "chapter",
    number: 1,
    title: "The Road to Bebeji",
    dek: "Fulbe families drift across the continent like seeds on the wind, and find a first home under the Kano emirate.",
    years: "16th – early 19th century",
    location: "Bebeji, Kano Emirate",
    coordinates: { lat: 11.53, lng: 8.33 },
    paragraphs: [
      "Between the sixteenth and eighteenth centuries, when the great empires of Europe were still struggling to find their footing, a wave of Fulbe families drifted across the African continent like seeds carried by the wind. They were not conquerors — they were seekers. They sought knowledge, they sought peace, and they sought a place where their children could grow strong in the faith of their fathers.",
      "The ancestors of the Yeros found their first home in Bebeji, a dominion of the Kano emirate. Here, in the heart of Hausaland, they encountered a people different from themselves — darker-skinned, with customs that spoke of ancient traditions, with a language that sounded like music to their ears.",
      "But the Fulbe were adaptable. They learned to speak Hausa alongside their native Fulfude. They traded with their neighbors, shared meals with their neighbors, and in time, they married their neighbors. The lines between Fulani and Hausa began to blur, like colors bleeding into each other on a painter's canvas.",
      "Then came the early nineteenth century, and with it, the Fulani jihad — a spiritual tempest that would reshape the political landscape of the region. Bebeji, the very place where the Yeros ancestors had found refuge, became the epicenter of the Kano jihad. The drums of war echoed through the streets, and the call to battle rang out from the minarets.",
      "The Yeros participated. They fought alongside their fellow Fulbe, their swords gleaming in the African sun, their hearts burning with the fire of righteous conviction. But when the dust settled and the blood dried, they realized that Bebeji could no longer be their home.",
      "Once again, they packed their belongings. Once again, they turned their faces toward the unknown."
    ],
    quote: "The lines between Fulani and Hausa began to blur, like colors bleeding into each other on a painter's canvas.",
    imagePrompt:
      "Epic wide-angle scene of a Fulani migration caravan crossing the West African savannah toward Bebeji: camel and cattle caravan, families on foot carrying woven bundles and calabashes, children walking beside herders, acacia trees and tall gold grass, dust catching afternoon light, distant silhouette of a Hausa walled town, cinematic documentary color grade, historically accurate 18th-century Fulbe and Hausa clothing, painterly realism, 8k.",
    facts: [
      "Bebeji was a dominion of the historic Kano Emirate.",
      "The early-19th-century Fulani jihad reshaped Hausaland's political map, with Bebeji at its epicenter of the Kano jihad."
    ]
  },
  {
    slug: "the-city-of-zaria",
    order: 2,
    kind: "chapter",
    number: 2,
    title: "The City of Zaria",
    dek: "A boy from Turawa walks alone to the great seat of learning — and returns a patriarch.",
    years: "Mid-19th century",
    location: "Zaria City, Zazzau Emirate (via Turawa)",
    coordinates: { lat: 11.07, lng: 7.7 },
    paragraphs: [
      "The ancestors eventually established themselves in Turawa, on the northeastern corner of the mighty Zazzau emirate. Here, they built homes, planted crops, and tried to forget the wars that had uprooted them. They raised children, told stories, and whispered prayers in the language of their homeland, even as their children grew up speaking Hausa.",
      "But one child would change everything. His name was Ahmad Yero, and from an early age, it was clear that he was different from his peers. While other children played in the dust, Ahmad sat with the elders, listening to their stories of faith and knowledge.",
      "\u201cIt is time,\u201d his father said one evening, as the sun painted the sky in shades of orange and gold. \u201cYou must go to Zaria City.\u201d Zaria City — the centre of learning of the great Sokoto Caliphate — was a name that carried weight. It was where scholars gathered like bees around honey.",
      "\u201cBut the journey is long,\u201d Ahmad's mother protested, her eyes already wet with tears. \u201cHe is too young. The roads are dangerous.\u201d \u201cHe is old enough,\u201d his father replied. \u201cHe carries our dreams with him. He will return a scholar.\u201d",
      "And so, in the mid-nineteenth century, young Ahmad Yero left Turawa. He traveled alone, his provisions tied in a simple cloth bundle, his Qur'an pressed against his chest. When he arrived in Zaria City, he was struck by its beauty — the towering minarets, the bustling markets, the crowds of scholars who seemed to flow through the streets like rivers of knowledge.",
      "But Ahmad Yero did not simply take from the city — he gave back. He became a teacher himself, his classes attended by students who traveled from far and wide. He served the emirate council, offering counsel and wisdom to those who governed. He married, raised children, and built a family that would one day bear his name. He became the patriarch of the Yeros."
    ],
    quote: "He carries our dreams with him. He will return a scholar.",
    imagePrompt:
      "Nineteenth-century Old Zaria City at golden hour: mudbrick minarets and city walls, a bustling historic market with indigo-dyed cloth and calabash traders, a young scholar (Ahmad Yero) in white robes walking through a crowded scholars' quarter with a Qur'an pressed to his chest, warm dust-lit atmosphere, Sokoto Caliphate-era architecture, luxury museum documentary lighting, richly detailed, 8k.",
    facts: [
      "Zaria City served as a major center of learning within the Sokoto Caliphate.",
      "Ahmad Yero is the founding patriarch from whom the Yero family takes its name."
    ]
  },
  {
    slug: "the-blending-of-blood",
    order: 3,
    kind: "chapter",
    number: 3,
    title: "The Blending of Blood",
    dek: "Generations of intermarriage reshape the Yeros' features, their tongue, and their sense of who they are.",
    years: "Late 19th – 20th century",
    location: "Zaria & Hausaland",
    paragraphs: [
      "Generations passed. The Yeros grew in number and influence, but they also grew in their adoption of Hausa culture. Intermarriage with the indigenous tribes of Hausaland changed their physical features. The delicate Fulani noses became broader, the lighter skin grew deeper in its melanin, the slender frames became sturdier.",
      "They also no longer spoke the language of those ancestors. Fulfude, the tongue that had once echoed through the Senegambian basin, slowly faded from their lips. In its place came Hausa, a language rich with poetry and proverbs, a language that connected them to the people among whom they now lived.",
      "\u201cShould we not teach our children Fulfude?\u201d one elder asked, his voice heavy with concern. \u201cWhat purpose would it serve?\u201d another replied. \u201cThey will grow up in Hausaland. They will marry Hausas. They will live among Hausas. Let them speak Hausa. Let them be Hausa.\u201d",
      "And so, the Yeros became Hausas by assimilation. But they did not forget completely. There remained a pride in their ancestry, a whisper in the blood that spoke of their origins. When outsiders asked where they came from, the Yeros would raise their heads and say, \u201cOur ancestors came from Futa Toro. We are Toronkawa. We are Fulbe.\u201d",
      "They were a bridge — a living connection between two worlds, two cultures, two identities. And that, they realized, was their gift to the world."
    ],
    quote: "Our ancestors came from Futa Toro. We are Toronkawa. We are Fulbe.",
    imagePrompt:
      "Warm intimate scene of Fulani and Hausa families gathered together in a traditional compound courtyard, sharing a meal, children of mixed heritage playing nearby, textiles and pottery reflecting both cultures side by side, soft afternoon light through a thatched awning, documentary portraiture style, respectful and dignified, historically accurate clothing and compound architecture, 8k.",
    facts: [
      "The Yero family's assimilation into Hausa culture is an example of a broader Fulani–Hausa cultural blending across Hausaland.",
      "Despite assimilation, the family retained oral memory of its Toronkawa / Futa Toro origins."
    ]
  },
  {
    slug: "the-faith-of-the-yeros",
    order: 4,
    kind: "chapter",
    number: 4,
    title: "The Faith of the Yeros",
    dek: "Dawn prayer as inheritance — and, in time, two rivers of faith flowing toward the same ocean.",
    years: "20th century",
    location: "Zaria",
    paragraphs: [
      "In the Yeros household, the dawn prayer was sacred. Long before the first rays of sunlight touched the horizon, the family would rise. Together, they would face Mecca and pray. This ritual had been passed down through generations, from the ancestors in Futa Toro to the scholars in Bebeji to the patriarch in Zaria. It was more than worship — it was identity.",
      "But the Yeros were also a family of change. In the early twentieth century, just as Christianity made its way into northern Nigeria, it found a foothold among the Yeros. \u201cA man cannot serve two masters,\u201d the elders warned. \u201cI am not serving two masters,\u201d the Christian convert replied. \u201cI am serving the same God in a different way.\u201d",
      "And so, the Yeros became a family of two faiths. But faith, they discovered, did not divide them. It united them. They still gathered for family celebrations. They still shared meals. They still mourned together and rejoiced together. Islam and Christianity coexisted in the Yeros household like two rivers flowing toward the same ocean."
    ],
    quote: "Islam and Christianity coexisted in the Yeros household like two rivers flowing toward the same ocean.",
    imagePrompt:
      "Serene pre-dawn interior scene: three generations of a Hausa-Fulani family gathered on a prayer mat in a simple mud-walled room, the Qibla wall marked, soft blue pre-dawn light mixing with a single oil lamp's warm glow, hands mid-prayer, deep sense of quiet unity, cinematic chiaroscuro lighting, respectful and reverent, historically grounded, 8k.",
    facts: [
      "The family's daily rhythm was anchored by the dawn (Fajr) prayer, passed down since the Futa Toro era.",
      "The Yeros became a family that includes both Muslim and Christian members who remain unified across generations."
    ]
  },
  {
    slug: "the-naming-ceremony",
    order: 5,
    kind: "chapter",
    number: 5,
    title: "The Naming Ceremony",
    dek: "On the seventh day, the newest Yero receives a name — and a place in the story.",
    years: "Ongoing tradition",
    location: "Zaria",
    paragraphs: [
      "When a child was born into the Yeros family, the entire community rejoiced. The mother would rest for seven days, the newborn wrapped in soft cloth, the household bustling with activity. Neighbors would come bearing gifts — fresh milk, sweet bread, words of blessing. The women would sing songs in Hausa, their voices rising and falling like the wind through the baobab trees.",
      "On the seventh day, after the dawn prayer, the family would gather. The child would be brought before the elders, its tiny face peering out from the folds of its blanket. The grandfather, the patriarch, would hold the infant in his arms, his old eyes studying the face of the new generation.",
      "\u201cWe shall call him Abdurrahman,\u201d the grandfather would announce, the name chosen from among the many that had been whispered in the weeks before. The child's uncles would nod in approval. The aunties would murmur their agreement.",
      "In these modern times, the practice had changed. The father often chose the name now, a reflection of shifting social ethics. But the essence remained. The naming was still an Islamic rite. The gathering was still a community affair."
    ],
    quote: "We shall call him Abdurrahman.",
    imagePrompt:
      "Traditional Islamic naming ceremony (Suna) on the seventh day: an elder patriarch holding a swaddled newborn before a seated circle of family elders in a courtyard, women in colorful wrappers singing in the background, gifts of milk and kola nuts laid on woven mats, warm midday sun, joyful and dignified documentary photography style, historically accurate Hausa-Fulani dress, 8k.",
    facts: [
      "The naming ceremony (Suna) traditionally takes place on the seventh day after birth.",
      "The choice of who names the child has shifted from grandfather-led to father-led over generations."
    ]
  },
  {
    slug: "growing-up-yero",
    order: 6,
    kind: "chapter",
    number: 6,
    title: "Growing Up Yero",
    dek: "Respect, hierarchy, and discipline — the first lessons a Yero child learns.",
    years: "Ongoing tradition",
    location: "Zaria",
    paragraphs: [
      "A child in the Yeros household learned its place in the world before it learned its letters. \u201cBaba,\u201d it would call its father. \u201cMama,\u201d it would call its mother. For uncles, it was \u201cBaba\u201d or \u201cKawu.\u201d For aunties, it was \u201cGogo\u201d or \u201cInna.\u201d",
      "The child learned respect early. It learned to call its elder siblings \u201cYaya,\u201d never daring to use their names. It understood, even before it could articulate the concept, that age commanded deference, that hierarchy was the glue that held the family together.",
      "Discipline was strict but loving. When the child misbehaved, anyone older could administer punishment. \u201cThere is no cruelty in discipline,\u201d the elders would say. \u201cWe are shaping you. We are preparing you for the world.\u201d",
      "And indeed, the world was harsh. The child would need strength, resilience, and discipline to survive. By learning these lessons at home, the child was prepared for the trials that lay beyond the family compound."
    ],
    quote: "We are shaping you. We are preparing you for the world.",
    imagePrompt:
      "Warm genre scene inside a traditional Hausa-Fulani family compound: children greeting elders with respectful bowed posture, an elder seated on a low stool observing with quiet authority, siblings of different ages in the courtyard, hand-built mud walls, woven mats, washing line, late-afternoon golden light, tender and authentic documentary style, 8k.",
    facts: [
      "Kinship terms like Baba, Kawu, Gogo, Inna and Yaya encode a precise respect hierarchy still used today."
    ]
  },
  {
    slug: "the-path-of-knowledge",
    order: 7,
    kind: "chapter",
    number: 7,
    title: "The Path of Knowledge",
    dek: "From wooden slate to Shari'a — the Islamic education of a Yero child, step by step.",
    years: "Ongoing tradition",
    location: "Zaria",
    paragraphs: [
      "At three or four years old, before their memories had fully formed, Yeros children began their Qur'anic education. The teacher was often a family member. The child would sit cross-legged on the floor, a wooden slate in front of it, a charcoal pen in its small hand. \u201cAlif, Ba, Ta, Tha,\u201d the teacher would recite, and the child would repeat.",
      "They learned the Arabic alphabet, and the last ten suras of the Holy Qur'an, memorizing the words through repetition. By six or seven, they were reading — starting from the short chapters and working their way to the long ones.",
      "At twelve, the education deepened. They began legal studies — fiqh — studying books like Akhadari, Ashimawi, Kurdubi, and Risalah. They read Hadith from Arba'unan Nawawee. They learned the basics of Tauheed, the oneness of God.",
      "By fourteen, they were ready for higher education. Shari'a, theology, Sira, and other fields of Islamic knowledge were now within their reach. The child had become a scholar, capable of diving into the deepest waters of faith."
    ],
    quote: "Alif, Ba, Ta, Tha.",
    imagePrompt:
      "Traditional Qur'anic school (Makarantar Allo) scene: young children seated in a circle on the ground holding wooden writing slates (allo) with Arabic script in black ink, a respected elderly teacher pointing to a verse, dust motes in warm sunlight filtering through a thatched roof, focused and reverent expressions, historically accurate, cinematic documentary realism, 8k.",
    facts: [
      "Traditional Qur'anic education begins as early as age three or four, starting with the Arabic alphabet on wooden slates.",
      "By age twelve, students progress to fiqh (Islamic law) texts such as Akhadari and Risalah."
    ]
  },
  {
    slug: "the-western-way",
    order: 8,
    kind: "chapter",
    number: 8,
    title: "The Western Way",
    dek: "Nursery, primary, secondary — a new kind of school arrives, and a new kind of Yero grows up inside it.",
    years: "20th – 21st century",
    location: "Zaria & beyond",
    paragraphs: [
      "The arrival of western education in the twentieth century brought new opportunities and new challenges. At first, Yeros children entered these schools at nine or ten, after the foundation of their Islamic education had been firmly laid. But the world was changing. The late twentieth and early twenty-first centuries saw a transformation in education that reduced the age of entry to three, four, or five.",
      "The child would attend nursery school, then primary school, then secondary — boarding school or day school, depending on the family's choice. In senior secondary, the child would choose a path: science or arts. This choice would determine university education, career, and future.",
      "The child would become a doctor, an engineer, a teacher, or a lawyer — a professional, contributing to society in ways the ancestors could never have imagined. But not all completed their education. Some dropped out, their paths taking unexpected turns into business or other ventures. This, too, was part of the Yeros story."
    ],
    quote: "A professional, contributing to society in ways the ancestors could never have imagined.",
    imagePrompt:
      "Split-composition documentary photograph showing generational transition in education: on one side a child with a Qur'anic wooden slate in a traditional courtyard, on the other a child in a crisp school uniform with books walking into a modern Nigerian classroom, soft transitional light bridging the two scenes, thoughtful and dignified tone, historically and culturally accurate, 8k.",
    facts: [
      "Entry age into western-style schooling for Yero children has fallen from roughly nine or ten to as young as three."
    ]
  },
  {
    slug: "serving-the-nation",
    order: 9,
    kind: "chapter",
    number: 9,
    title: "Serving the Nation",
    dek: "In government, business, academia, and the mosque, the Yeros give back to Nigeria.",
    years: "20th – 21st century",
    location: "Nigeria",
    paragraphs: [
      "The Yeros had given much to Nigeria. Throughout history, they had held offices in federal and state governments, their voices rising in the corridors of power. They had built private enterprises, creating opportunities and prosperity for their communities. They had served as teachers, from primary schools to universities, shaping the minds of the nation.",
      "In academia, they had produced intellectuals who influenced the discourse of their time. Their ideas were debated in lecture halls, their writings read by students, their legacy carried forward by the generations they had taught.",
      "In Islamic scholarship, they had preserved the family's heritage. There had always been Yeros scholars who taught the sacred sciences, who guided the community through prayer and wisdom, who kept the flame of faith burning bright. And they continued. The Yeros of today still served. They still taught. They still built. They still remembered the lessons of their ancestors."
    ],
    quote: "They still taught. They still built. They still remembered the lessons of their ancestors.",
    imagePrompt:
      "Dignified montage-style documentary composition of Yero family members in public service: a scholar teaching at a lectern, an official in a government office, an entrepreneur at a bustling market stall, an Islamic teacher instructing students under a tree, warm unified color grade tying the scenes together, National Geographic editorial photography style, respectful, contemporary Nigerian setting, 8k.",
    facts: [
      "Family members have served across government, private enterprise, academia, and Islamic scholarship in Nigeria."
    ]
  },
  {
    slug: "the-legacy-of-unity",
    order: 10,
    kind: "chapter",
    number: 10,
    title: "The Legacy of Unity",
    dek: "Distance did not break them. Time did not break them. The Yeros remain one body, many parts.",
    years: "Present day",
    location: "Nigeria & the diaspora",
    paragraphs: [
      "The Yeros were not perfect. No family is. But they were remarkable in their unity. Their predecessors had lived lives of achievement and love, of respect and equity, of strength that came from their bonds. They lived as one entity, a single body with many parts, each contributing to the whole.",
      "\u201cThere will be bridges that set us apart,\u201d one elder once said, \u201cbut we must never let those bridges divide us.\u201d And they never did. Distance did not break them. Time did not break them. Challenges did not break them. They remained the Yeros — a family, a legacy, a symbol of brotherhood.",
      "Their lives and values were something everyone could crave. They were a true symbol of what families could become when they remembered their roots, honored their heritage, and looked toward the future with faith and hope."
    ],
    quote: "There will be bridges that set us apart, but we must never let those bridges divide us.",
    imagePrompt:
      "Grand, warm family portrait scene: a large multigenerational Hausa-Fulani family gathered in a courtyard for a celebration, grandparents seated in the center, children and grandchildren arranged around them, traditional and modern dress mingling, string lights or lanterns at dusk, joyful candid expressions, cinematic golden-hour documentary photography, 8k.",
    facts: [
      "The family's defining value across ten generations has been unity across distance, time, and difference."
    ]
  },
  {
    slug: "epilogue",
    order: 11,
    kind: "epilogue",
    title: "Footprints in the Sand",
    dek: "From Futa Toro to Zaria to the nation — a mark too deep to ever disappear.",
    location: "Futa Toro → Bebeji → Zaria → Nigeria",
    paragraphs: [
      "The wind blows across the African savanna, carrying the dust of centuries. In the Senegambian basin, the ruins of Takrur lie silent, their stones whispering secrets of the past. In Bebeji, the echoes of the jihad have long faded. In Zaria City, the scholars still gather, their voices rising in prayer.",
      "And the Yeros endure. They are the descendants of Futa Toro, the children of Malam Ahmad Yero, the bearers of a legacy that stretches across centuries and continents. They are Hausas by assimilation, Fulbe by blood, Muslims and Christians by faith, Nigerians by nationality.",
      "But above all, they are the Yeros — a family that has left its mark on the world. Their footprint will never be erased from the sand of time. For in that sand, where the wind might sweep away the tracks of lesser feet, the Yeros have left their mark too deep, too enduring, too meaningful to ever disappear.",
      "They are the bridge between worlds. They are the living memory of their ancestors. They are the hope for the future. This is their story. This is their legacy. This is the Yeros."
    ],
    quote: "Their footprint will never be erased from the sand of time.",
    imagePrompt:
      "A line of human footprints crossing a vast golden sand dune in the African savannah at sunrise, long dramatic shadows, warm orange and rose sky, a distant silhouette of an acacia tree and a family walking toward the horizon, cinematic, symbolic, National Geographic documentary photography, ultra wide, 8k, emotionally resonant closing image.",
    facts: []
  }
];

export const getChapterBySlug = (slug: string) => chapters.find((c) => c.slug === slug);

export const bookChapters = chapters.filter((c) => c.kind === "chapter");

export const journeyRoute = [
  { label: "Futa Toro (Takrur)", coordinates: { lat: 16.5, lng: -14.0 }, era: "Before 16th c." },
  { label: "Senegal & Gambia Rivers", coordinates: { lat: 14.8, lng: -13.5 }, era: "Migration route" },
  { label: "Bebeji, Kano Emirate", coordinates: { lat: 11.53, lng: 8.33 }, era: "16th–19th c." },
  { label: "Turawa, Zazzau Emirate", coordinates: { lat: 11.2, lng: 7.9 }, era: "Early 19th c." },
  { label: "Zaria City", coordinates: { lat: 11.07, lng: 7.7 }, era: "Mid-19th c. — present" },
  { label: "Modern Nigeria", coordinates: { lat: 9.08, lng: 8.68 }, era: "Present day" }
];
