// Client-side Firebase config.
// Fill in /.env.local from .env.local.example before using auth/CMS features.
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

export const firebaseApp = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(firebaseApp);
export const storage = getStorage(firebaseApp);
export const auth = getAuth(firebaseApp);

/**
 * Firestore collections used by the CMS / admin dashboard:
 *   chapters/{slug}        -> editable chapter copy, overrides lib/chapters.ts
 *   gallery/{imageId}      -> { url, caption, chapterSlug, credit }
 *   familyTree/{personId}  -> { name, parentId, birthYear, note, photoUrl }
 *   news/{postId}          -> { title, body, publishedAt, coverUrl }
 *   documents/{docId}      -> { title, fileUrl, description }
 *
 * Storage buckets:
 *   /gallery/{chapterSlug}/...
 *   /family-tree/{personId}/...
 *   /documents/...
 */
