import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Design tokens — see README "Design System"
        sand: "#E8DCC8",
        "sand-light": "#F3ECDD",
        gold: "#C89B3C",
        "gold-bright": "#E0B24E",
        brown: "#3E2723",
        "brown-deep": "#241512",
        emerald: "#1B4332",
        "emerald-light": "#2D6A4F",
        warmwhite: "#FAF6EE",
        charcoal: "#1A1A1A",
        "charcoal-soft": "#242220"
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"]
      },
      letterSpacing: {
        widest2: "0.25em"
      },
      backgroundImage: {
        "grain": "url('/images/grain.png')"
      },
      keyframes: {
        drift: {
          "0%": { transform: "translateX(0) translateY(0)" },
          "100%": { transform: "translateX(-4%) translateY(-2%)" }
        },
        footstep: {
          "0%, 100%": { opacity: "0.15" },
          "50%": { opacity: "0.55" }
        }
      },
      animation: {
        drift: "drift 40s ease-in-out infinite alternate",
        footstep: "footstep 2.4s ease-in-out infinite"
      }
    }
  },
  plugins: []
};

export default config;
